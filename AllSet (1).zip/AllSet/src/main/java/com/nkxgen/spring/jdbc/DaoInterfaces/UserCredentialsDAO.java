package com.nkxgen.spring.jdbc.DaoInterfaces;

public interface UserCredentialsDAO {

	boolean userCredentialsCheck(String username, String password);

}
