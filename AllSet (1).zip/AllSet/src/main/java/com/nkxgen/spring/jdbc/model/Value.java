package com.nkxgen.spring.jdbc.model;

public class Value {
	String value;

	public void setvalue(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}
}
